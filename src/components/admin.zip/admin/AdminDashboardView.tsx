import { useState, useEffect } from 'react';
import { Phone, PhoneCall, PhoneMissed, Users, TrendingUp, Clock, FileText, UserCheck, Upload } from 'lucide-react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface KPIData {
  totalLeads: number;
  totalCalls: number;
  connectedCalls: number;
  notConnectedCalls: number;
  todayCalls: number;
  activeStaff: number;
  activeManagers: number;
  totalUploads: number;
  leadsUploadedToday: number;
  leadsByLoanType: Array<{
    name: string;
    code: string;
    count: number;
  }>;
}

interface LoanCategoryData {
  name: string;
  value: number;
}

interface CallStatusData {
  name: string;
  value: number;
  color: string;
}

interface StaffPerformanceData {
  name: string;
  calls: number;
  connected: number;
  rate: number;
}

interface DailyCallsData {
  date: string;
  connected: number;
  notConnected: number;
}

export function AdminDashboardView() {
  const [kpiData, setKpiData] = useState<KPIData>({
    totalLeads: 0,
    totalCalls: 0,
    connectedCalls: 0,
    notConnectedCalls: 0,
    todayCalls: 0,
    activeStaff: 0,
    activeManagers: 0,
    totalUploads: 0,
    leadsUploadedToday: 0,
    leadsByLoanType: []
  });

  const [loanCategories, setLoanCategories] = useState<LoanCategoryData[]>([]);
  const [callStatusData, setCallStatusData] = useState<CallStatusData[]>([]);
  const [staffPerformance, setStaffPerformance] = useState<StaffPerformanceData[]>([]);
  const [dailyCalls, setDailyCalls] = useState<DailyCallsData[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch dashboard data
  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const token = localStorage.getItem('token');
        
        // Fetch KPI data
        const kpiResponse = await fetch('/api/admin/dashboard/kpi', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        
        if (kpiResponse.ok) {
          const kpiResult = await kpiResponse.json();
          setKpiData(kpiResult);
          
          // Update loan categories from API data
          if (kpiResult.leadsByLoanType && kpiResult.leadsByLoanType.length > 0) {
            setLoanCategories(kpiResult.leadsByLoanType.map((item: any) => ({
              name: item.name,
              value: item.count
            })));
          }
        }

        // Mock data for charts (replace with actual API calls)
        if (loanCategories.length === 0) {
          setLoanCategories([
            { name: 'Car Loan', value: 1250 },
            { name: 'Home Loan', value: 980 },
            { name: 'Personal Loan', value: 750 },
            { name: 'Business Loan', value: 420 },
            { name: 'Education Loan', value: 180 }
          ]);
        }

        setCallStatusData([
          { name: 'Connected', value: kpiData.connectedCalls || 1923, color: '#10b981' },
          { name: 'Not Connected', value: kpiData.notConnectedCalls || 924, color: '#ef4444' },
          { name: 'Busy', value: 450, color: '#f59e0b' },
          { name: 'Wrong Number', value: 280, color: '#3b82f6' }
        ]);

        setStaffPerformance([
          { name: 'Rajesh Kumar', calls: 450, connected: 320, rate: 71 },
          { name: 'Priya Sharma', calls: 420, connected: 295, rate: 70 },
          { name: 'Amit Patel', calls: 380, connected: 260, rate: 68 },
          { name: 'Sneha Reddy', calls: 390, connected: 270, rate: 69 },
          { name: 'Vikram Singh', calls: 410, connected: 285, rate: 70 },
          { name: 'Neha Gupta', calls: 370, connected: 255, rate: 69 },
          { name: 'Rahul Verma', calls: 395, connected: 275, rate: 70 },
          { name: 'Anjali Desai', calls: 385, connected: 265, rate: 69 },
          { name: 'Karan Malhotra', calls: 405, connected: 290, rate: 72 },
          { name: 'Pooja Nair', calls: 375, connected: 250, rate: 67 }
        ]);

        setDailyCalls([
          { date: 'Mon', connected: 320, notConnected: 140 },
          { date: 'Tue', connected: 380, notConnected: 160 },
          { date: 'Wed', connected: 420, notConnected: 130 },
          { date: 'Thu', connected: 390, notConnected: 150 },
          { date: 'Fri', connected: 450, notConnected: 120 },
          { date: 'Sat', connected: 410, notConnected: 145 },
          { date: 'Sun', connected: 380, notConnected: 155 }
        ]);

      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  const stats = [
    {
      label: 'Total Leads',
      value: kpiData.totalLeads.toLocaleString(),
      change: '+8.2%',
      trend: 'up',
      icon: FileText,
      color: 'bg-blue-500',
    },
    {
      label: 'Total Calls Made',
      value: kpiData.totalCalls.toLocaleString(),
      change: '+12.5%',
      trend: 'up',
      icon: Phone,
      color: 'bg-purple-500',
    },
    {
      label: 'Connected Calls',
      value: kpiData.connectedCalls.toLocaleString(),
      change: '+8.3%',
      trend: 'up',
      icon: PhoneCall,
      color: 'bg-green-500',
    },
    {
      label: 'Not Connected',
      value: kpiData.notConnectedCalls.toLocaleString(),
      change: '-5.2%',
      trend: 'down',
      icon: PhoneMissed,
      color: 'bg-red-500',
    },
    {
      label: "Today's Calls",
      value: kpiData.todayCalls.toLocaleString(),
      change: '+15.3%',
      trend: 'up',
      icon: Clock,
      color: 'bg-orange-500',
    },
    {
      label: 'Active Staff',
      value: kpiData.activeStaff.toString(),
      change: '+2',
      trend: 'up',
      icon: UserCheck,
      color: 'bg-indigo-500',
    },
    {
      label: 'Active Managers',
      value: kpiData.activeManagers.toString(),
      change: '+1',
      trend: 'up',
      icon: Users,
      color: 'bg-teal-500',
    },
    {
      label: 'Total Uploads',
      value: kpiData.totalUploads.toString(),
      change: '+3',
      trend: 'up',
      icon: Upload,
      color: 'bg-pink-500',
    },
    {
      label: 'Leads Uploaded Today',
      value: kpiData.leadsUploadedToday.toLocaleString(),
      change: '+24.5%',
      trend: 'up',
      icon: TrendingUp,
      color: 'bg-cyan-500',
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div
              key={index}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 ${stat.color} rounded-lg flex items-center justify-center`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <span
                  className={`text-sm font-medium flex items-center gap-1 ${
                    stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                  }`}
                >
                  <TrendingUp className={`w-4 h-4 ${stat.trend === 'down' ? 'rotate-180' : ''}`} />
                  {stat.change}
                </span>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">
                {stat.value}
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pie Chart - Leads by Loan Type */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Leads by Loan Type
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={loanCategories}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {loanCategories.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'][index % 5]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1f2937',
                  border: 'none',
                  borderRadius: '8px',
                  color: '#fff',
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Bar Chart - Calls by Status */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Calls by Status
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={callStatusData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.2} />
              <XAxis dataKey="name" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1f2937',
                  border: 'none',
                  borderRadius: '8px',
                  color: '#fff',
                }}
              />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {callStatusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Daily Calls Trend */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          Daily Calls Trend
        </h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={dailyCalls}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.2} />
            <XAxis dataKey="date" stroke="#6b7280" />
            <YAxis stroke="#6b7280" />
            <Tooltip
              contentStyle={{
                backgroundColor: '#1f2937',
                border: 'none',
                borderRadius: '8px',
                color: '#fff',
              }}
            />
            <Legend />
            <Line type="monotone" dataKey="connected" stroke="#10b981" strokeWidth={2} name="Connected" />
            <Line type="monotone" dataKey="notConnected" stroke="#ef4444" strokeWidth={2} name="Not Connected" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Staff Performance Table */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          Staff Performance (Top 10)
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 dark:border-gray-700">
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-600 dark:text-gray-400">
                  Staff Name
                </th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-600 dark:text-gray-400">
                  Total Calls
                </th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-600 dark:text-gray-400">
                  Connected
                </th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-600 dark:text-gray-400">
                  Success Rate
                </th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-600 dark:text-gray-400">
                  Performance
                </th>
              </tr>
            </thead>
            <tbody>
              {staffPerformance.slice(0, 10).map((staff, index) => (
                <tr
                  key={index}
                  className="border-b border-gray-100 dark:border-gray-700/50 hover:bg-gray-50 dark:hover:bg-gray-700/30"
                >
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-900/30 rounded-lg flex items-center justify-center">
                        <UserCheck className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                      </div>
                      <span className="font-medium text-gray-900 dark:text-white">
                        {staff.name}
                      </span>
                    </div>
                  </td>
                  <td className="py-4 px-4 text-gray-900 dark:text-white">{staff.calls}</td>
                  <td className="py-4 px-4 text-gray-900 dark:text-white">{staff.connected}</td>
                  <td className="py-4 px-4">
                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                      staff.rate >= 70 
                        ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400'
                        : staff.rate >= 60
                        ? 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400'
                        : 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400'
                    }`}>
                      {staff.rate}%
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${
                          staff.rate >= 70 ? 'bg-green-500' : staff.rate >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                        }`}
                        style={{ width: `${staff.rate}%` }}
                      ></div>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
